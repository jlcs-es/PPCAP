#!/bin/bash

module load intel/2017_u1
source /etc/profile.d/modules.sh
source /opt/intel/composerxe/bin/compilervars.sh intel64
