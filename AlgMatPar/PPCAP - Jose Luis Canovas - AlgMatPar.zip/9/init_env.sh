#!/bin/bash

source /etc/profile.d/modules.sh
source /opt/intel/composerxe/bin/compilervars.sh intel64

module load intel/2017_u1
module load openmpi/1.6.4-intel
