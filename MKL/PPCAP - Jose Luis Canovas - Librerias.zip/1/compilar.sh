icc -o $1 $1.c io.c -lm -O3
